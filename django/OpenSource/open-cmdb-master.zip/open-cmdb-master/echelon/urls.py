from django.conf.urls import patterns

urlpatterns = patterns('echelon.views', ('^$', 'changelog'), )