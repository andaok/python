from django.contrib import admin
from jobapp.models import DynamicGroup , SaltGroup
# Register your models here.



admin.site.register(DynamicGroup)
admin.site.register(SaltGroup)

